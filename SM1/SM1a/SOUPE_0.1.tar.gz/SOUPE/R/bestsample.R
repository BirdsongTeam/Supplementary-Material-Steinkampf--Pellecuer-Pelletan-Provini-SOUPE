#' @title bestsample
#' @author Nyniane Steinkampf--Pellecuer <nyniane.steinkampf-pellecuer@mnhn.fr>
#' @author Idriss Pelletan <idriss.pelletan@laposte.net>
#'
#' @description Creates a sample that maximizes the PD_Faith.
#'
#' @param tree the phylogenetic \code{tree} of the master-group. By default, tree = NULL, must be defined by the user.
#' @param init a \code{string} containing the species to initiate the iteration. We advise to start with the most "basal" taxa of the phylogeny if the tree is ultrametric. If the tree is non-ultrametric, the taxa with the longest branch length should be preferentially chosen. It is also possible to include here key species that have to be included in the study. By default, init = NULL, must be defined by the user.
#' @param type a \code{string}. If type = "number", the sample will be created to reach a number of taxa. If type = "percentage", the sample will be created to reach a percentage of phylogeny represented (PPR). By default, type = "number".
#' @param n a \code{numeric}. If type ="number", n is the number of taxa to reach. If type = "percentage", n is the PPR to reach, expressed between 0 and 100. By default, n = NULL, must be defined by the user.
#' @param list a \code{string} with the available taxa. The names of the taxa have to match the labels of the phylogenetic tree. If there is no restriction on the availability of the taxa, write list = tree$tip.labels ("tree" being the name of the phylogenetic tree). By default, list = NULL, must be defined by the user.
#' @param history a \code{logical}. If history = TRUE, save an history of the different possible taxa at each iteration of the code. By default, history = TRUE.
#' @param sub_phylo a \code{logical}. If sub_phylo=TRUE, plot the fan phylogenetic tree of the created sample, based on the master-group tree. By default, sub_phylo = TRUE.
#' @param save_sub_phylo only if sub_phylo = TRUE. Give the path of a location to save the phylogeny of the created sample in a nexus file at this given location. If save_sub_phylo = NULL, the phylogeny is plotted but not saved. By default, save_sub_phylo = NULL, the phylogeny is not saved.
#' @return result a \code{list} containing the following elements : Best_sample : the sample created by the code. PD_Faith : the PD_Faith value of the sample. PPR : the Percentage of Phylogeny Represented of the sample. History : if history = TRUE, the history of the creation of the sample. Phylogeny : if sub_phylo = TRUE, the phylogenetic tree of the created sample.
#' @importFrom ape write.nexus drop.tip
#' @importFrom epm faithPD
#' @importFrom utils tail
#' @examples
#' # with a number of taxa to reach
#' bestsample(tree = ex_tree,
#'            init = c("G"),
#'            type = "number",
#'            n = 5,
#'            list = ex_available_taxa,
#'            history = TRUE,
#'            sub_phylo = TRUE)
#'
#' #In this example, list=ex_available_taxa  because there is a limit on the
#' #availability of the taxa. We could have use list=ex_tree$tip.label for a
#' #non-limited list of available taxa.
#'
#' # with a PPR to reach
#' bestsample(tree = ex_tree,
#'            init = c("G"),
#'            type = "percentage",
#'            n = 75,
#'            list = ex_available_taxa,
#'            history = TRUE,
#'            sub_phylo = TRUE)
#'
#' #In this example, list=ex_available_taxa  because there is a limit on the
#' #availability of the taxa. We could have use list=ex_tree$tip.label for a
#' #non-limited list of available taxa.
#' @export
#'
#'


bestsample <- function(tree = NULL, init = NULL, type = "number", n = NULL, list = NULL, history = TRUE, sub_phylo = TRUE, save_sub_phylo = NULL) {

  if (is.null(tree)==TRUE) {
    stop("tree is missing")
  }
  if (is.null(init)==TRUE) {
    stop("init is missing")
  }
  if (type != "number" & type != "percentage") {
    stop("type is not correct")
  }
  if (is.numeric(n)==FALSE) {
    stop("n is not a numerical value")
  }
  if (is.null(list)==TRUE) {
    stop("list is missing")
  }
  if (is.logical(history)==FALSE) {
    stop("history argument is not logical")
  }
  if (all(init %in% tree$tip.label) == FALSE) {
    stop("init species don't match phylogenetic tree species")
  }
  if (all(list %in% tree$tip.label) == FALSE) {
    stop("available species don't match phylogenetic tree species")
  }
  if (all(init %in% list) == FALSE) {
    stop("init species don't match available species")
  }

  sample <- init #starting the taxa list
  taxo_tree <- tree$tip.label
  tree_length <- epm::faithPD(tree, taxo_tree) #tree length for PPR calculation
  faith_sample <- epm::faithPD(tree, sample) #PD_Faith of the sample

  result<-list()

  if(history == TRUE) { #create a list to store the history
    hist <- list(sample)
    i=length(sample)+1
  }

  if (type == "number") { #in case one wants to reach a certain number of taxa

    if (length(sample) >= n) {
      stop("sample already reach the requested number of taxa")
    }
    while (length(sample) < n) {

      #progress
      faith_sample <- epm::faithPD(tree, sample)
      perc_sample <- (faith_sample/tree_length)*100
      cat("Number of selected species :", length(sample), "/", n, " species", ", " , " PD_Faith = ", faith_sample, " PPR = ", perc_sample, "% \n")

      #candidate species
      remaining_species <- setdiff(list, sample)

      #for each candidate species, calculate the PD_Faith it would give if added to the sample
      pd_values <- sapply(remaining_species, function(sp) epm::faithPD(tree, c(sample, sp)))

      #select the species that gives the maximal PD_Faith
      best_candidate <- remaining_species[which.max(pd_values)]
      sample <- c(sample, best_candidate)

      #history
      if (history==TRUE) {
        hist[[i]] <- names(which(pd_values == max(pd_values)))
        i=i+1
      }

      #progress
      faith_sample <- epm::faithPD(tree, sample)
      perc_sample <- (faith_sample/tree_length)*100
      cat("Number of selected species :", length(sample), "/", n, " species", ", " , " PD_Faith = ", faith_sample, " PPR = ", perc_sample, "% \n")

    }
    result <- list(hist, sample, faith_sample, perc_sample)
    print("Number of species reached!")
  }


  else if (type=="percentage") {

    starting_perc <- (faith_sample/tree_length)*100
    percentages <- c(starting_perc)

    if (starting_perc >= n) {
      stop("sample already reach the requested PPR.")
    }

    while (utils::tail(percentages,1) < n) {

      # progress
      faith_sample <- epm::faithPD(tree, sample)
      perc_sample <- (faith_sample/tree_length)*100
      cat("Number of selected species :", length(sample) , " PD_Faith = ", faith_sample, " PPR = ", perc_sample, " % / ", n, "%" ,"\n")

      #retrieve candidate species
      remaining_species <- setdiff(list, sample)

      #for each candidate species, calculate the PD_Faith it would give if added to the sample
      pd_values <- sapply(remaining_species, function(sp) epm::faithPD(tree, c(sample, sp)))

      #select the species that gives the maximal PD_Faith
      best_candidate <- remaining_species[which.max(pd_values)]
      sample <- c(sample, best_candidate)

      #history
      if (history==TRUE) {
        hist[[i]] <- names(which(pd_values == max(pd_values)))
        i=i+1
      }
      #progress
      faith_sample <- epm::faithPD(tree, sample)
      perc_sample <- (faith_sample/tree_length)*100
      percentages <- c(percentages, perc_sample)
      cat("Number of selected species :", length(sample), " PD_Faith = ", faith_sample, " PPR = ", perc_sample, " / ", n, "%" ,"\n")

    }
    result<-list(hist, sample, faith_sample, perc_sample)
    print("PPR reached!")
  }

  names(result) <- c("History", "Best_sample", "PD_Faith", "PPR")

  if (sub_phylo == TRUE) {
    sub.tree <- ape::drop.tip(tree, tree$tip.label[-match(sample, tree$tip.label)])
    result[["Phylogeny"]] <- sub.tree

    if (is.null(save_sub_phylo)){
      plot(sub.tree, type="fan", cex=0.5)
    }

    else {
      plot(sub.tree, type="fan", cex=0.5)
      ape::write.nexus(sub.tree, file=file.path(save_sub_phylo)) #save the sample
    }
  }
  return(result)

}

