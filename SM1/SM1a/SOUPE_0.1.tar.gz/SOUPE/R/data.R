#' SOUPE
#'
#' The SOUPE package is a method to test the phylogenetic relevance of a taxonomical sample, and to help with the creation of an optimized taxonomical sample taking into account the phylogeny and other traits (e.g., ecological, morphological characteristics, etc).
#' @docType package
#' @name SOUPE
"_PACKAGE"

#' ex_tree
#'
#' A theoretical phylogenetic tree of 7 taxa : A, B, C, D, E, F, G.
#' @format \code{tree}
"ex_tree"
NULL

#' ex_tested_sample
#'
#' A sample to be tested.
#' @format \code{string}
"ex_tested_sample"
NULL

#' ex_available_taxa
#'
#' A list of available taxa.
#' @format \code{string}
"ex_available_taxa"
NULL

#' ex_traits_table
#'
#' A table with traits characteristics for each taxa of the phylogeny: Habitat (Sea, Mountain, Forest), Feeding.style (Carnivorous, Herbivorous, Omnivorous), Size (Big, Medium, Small).
#' @format \code{data.frame}
"ex_traits_table"
NULL

