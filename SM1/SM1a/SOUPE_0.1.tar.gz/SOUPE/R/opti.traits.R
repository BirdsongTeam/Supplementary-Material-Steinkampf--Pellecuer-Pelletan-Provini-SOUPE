#' @title opti.traits
#' @author Nyniane Steinkampf--Pellecuer <nyniane.steinkampf-pellecuer@mnhn.fr>
#' @author Idriss Pelletan <idriss.pelletan@laposte.net>
#'
#' @description Creates an optimized sample taking into account phylogeny and other traits (e.g., ecological, morphological etc).
#'
#' @param tree the phylogenetic \code{tree} of the master group. By default, tree = NULL, must be defined by the user.
#' @param n the number of taxa to reach. By default, n = NULL, must be defined by the user.
#' @param list a \code{string} with the available taxa. The names of the taxa have to match the labels of the phylogenetic tree. If there is no restriction on the availability of the taxa, write list = tree$tip.labels (tree being the name of the phylogenetic tree). By default, list = NULL, must be defined by the user.
#' @param keyspe a \code{string} where the user can ask for key taxa to be included in the sample. By default : keyspe = NULL, meaning that the user doesn't want to especially include some species in the sample.
#' @param traits_table a \code{data.frame} with the traits characteristics of each species. These traits and characteristics have to be discrete and non-numeric. First column must be named "Species" and contains the species of the phylogenetic tree. By default, traits.table = NULL, must be defined by the user.
#' @param proportions a \code{list} containing the proportions to reach in each traits characteristics. Traits should be in the same order as they appear in the table. By default, proportions = NULL, must be defined by the user.
#' @param traits_weight a \code{string} containing the relative weights of each traits. It should sum up to 1, and be the same length than proportions (i.e. length(proportions)=length(traits_weight)). By default, traits_weight = NULL, must be defined by the user.
#' @param delta a \code{numeric} representing the relative weight between phylogeny and ecology. The value should be comprised between 0 and 1. When delta = 0, only the phylogeny is taken into account, the result is the same as with the bestsample function, the sample is not optimized according to the traits. When delta = 1, only the traits are taken into account, the sample is not phylogenetically optimized. By default, delta = 0.5, same weight for phylogeny and ecology.
#' @param history a \code{logical}. If history = TRUE, save an history of the creation of the sample. By default, history = FALSE.
#' @param sub_phylo a \code{logical}. If sub_phylo=TRUE, plot the fan phylogenetic tree of the created sample, based on the master-group tree. By default, sub_phylo = TRUE.
#' @param save_sub_phylo only if sub_phylo = TRUE. Give the path of a location to save the phylogeny of the created sample in a nexus file at this given location. If save_sub_phylo = NULL, the phylogeny is plotted but not saved. By default, save_sub_phylo = NULL, the phylogeny is not saved.
#' @return result a \code{list} containing the following elements : Best_sample : the sample created by the function. PD_Faith : the PD_Faith value of the sample. PPR : the Percentage of Phylogeny Represented of the sample. Traits : the proportions and number of taxa reached in each traits characteristics asked. History : the history if asked. Phylogeny : if sub_phylo = TRUE, the phylogenetic tree of the created sample.
#' @importFrom epm faithPD
#' @importFrom ape write.nexus drop.tip
#' @importFrom purrr map_dbl %>%
#' @examples
#' #Set proportions to reach
#' proportions <- list(Habitat = c("Sea" = 0.5,
#'                                 "Forest" = 0.5,
#'                                 "Mountain" = 0),
#'                     Feeding.style = c("Carnivorous" = 0.33,
#'                                       "Omnivorous" = 0.33,
#'                                       "Herbivorous" = 0.34),
#'                     Size = c("Big" = 0.33,
#'                              "Medium" = 0.33,
#'                              "Small" = 0.34))
#'
#' #Set traits weight : same weight for all the three traits
#'
#' traits_weight <- c(0.3, 0.3, 0.3)
#'
#' #Creation of the sample
#' opti.traits(tree = ex_tree,
#'             n = 5,
#'             list = ex_available_taxa,
#'             traits_table = ex_traits_table,
#'             proportions = proportions,
#'             traits_weight = traits_weight,
#'             delta = 0.5,
#'             history = FALSE,
#'             sub_phylo = TRUE)
#'
#' #Creation of a sample with optimization for phylogeny only : delta = 0
#' opti.traits(tree = ex_tree,
#'             n = 5,
#'             list = ex_available_taxa,
#'             traits_table = ex_traits_table,
#'             proportions = proportions,
#'             traits_weight = traits_weight,
#'             delta = 0,
#'             history = FALSE,
#'             sub_phylo = TRUE)
#'
#' #Creation of a sample with optimization for ecology only : delta = 1
#' opti.traits(tree = ex_tree,
#'             n = 5,
#'             list = ex_available_taxa,
#'             traits_table = ex_traits_table,
#'             proportions = proportions,
#'             traits_weight = traits_weight,
#'             delta = 1,
#'             history = FALSE,
#'             sub_phylo = TRUE)
#'
#' #Creation of a sample with G included as a key species
#' opti.traits(tree = ex_tree,
#'             n = 5,
#'             list = ex_available_taxa,
#'             keyspe = c("G"),
#'             traits_table = ex_traits_table,
#'             proportions = proportions,
#'             traits_weight = traits_weight,
#'             delta = 0.5,
#'             history = FALSE,
#'             sub_phylo = TRUE)
#' @export
#'


opti.traits <- function(tree = NULL, n = NULL, list = NULL, keyspe=NULL, traits_table = NULL, proportions = NULL, traits_weight = NULL, delta = 0.5, history = FALSE, sub_phylo = TRUE, save_sub_phylo = NULL){

  if (is.null(tree)==TRUE) {
    stop("tree is missing")
  }
  if (is.numeric(n)==FALSE) {
    stop("n is not a numerical value")
  }
  if (is.null(list)==TRUE) {
    stop("list of available taxa is missing")
  }
  if (is.null(traits_table)==TRUE) {
    stop("traits table is missing")
  }
  if (is.null(proportions)==TRUE) {
    stop("proportions to reach are missing")
  }
  if (is.null(traits_weight)==TRUE) {
    stop("weights for each traits are missing")
  }
  if (is.numeric(delta)==FALSE) {
    stop("delta is not a numerical value")
  }
  if (is.logical(history)==FALSE) {
    stop("history argument is not logical")
  }
  if (all(traits_table$Species %in% tree$tip.label) == FALSE) {
    stop("traits table species don't match phylogenetic tree species")
  }
  if (all(list %in% tree$tip.label) == FALSE) {
    stop("available species don't match phylogenetic tree species")
  }
  if (all(keyspe %in% tree$tip.label) == FALSE) {
    stop("key species don't match phylogenetic tree species")
  }
  if (length(sample) >= n) {
    stop("sample already reach the requested number of taxa")
  }
  if (all(keyspe %in% list) == FALSE) {
    stop("key species don't match available species")
  }
  if (all(list %in% traits_table$Species) == FALSE) {
    stop("available species don't match traits table species")
  }

  taxo_tree <- tree$tip.label
  tree_length <- epm::faithPD(tree, taxo_tree) #tree length for percentage calculation

  #storage
  result <- list()
  sample <- character(0)

  if (is.null(keyspe)==FALSE) {
    sample <- keyspe
  }

  #function to calculate the traits score of a sample
  gap_calculation <- function(sample, traits_table, proportions) {
    if(length(sample) == 0) return(0)
    required_cols <- names(proportions)
    if(!all(required_cols %in% names(traits_table))) {
      missing <- setdiff(required_cols, names(traits_table))
      stop(paste("missing column in traits_table :", paste(missing, collapse = ", ")))
    }
    spec_in_table <- subset(traits_table, traits_table$Species %in% sample) #traits of the species in a sample
    spec_in_table
    n <- length(traits_table)-1
    gaps <- list()
    for (i in 1:n) {
      cat_param <- traits_table[[names(proportions)[i]]] %>% unique()
      cat_param <- sort(cat_param)  #retrieve the ecological categories of the parameter
      counts_table_param <- table(factor(spec_in_table[[names(proportions)[i]]], levels = cat_param)) #calculates the number of species of the sample in each ecological category
      counts_prop_param <- prop.table(counts_table_param) #calculates the proportion of species of the sample in each categories
      sum_param <- sum(abs(counts_prop_param - proportions[[i]])) #calculate the gap of the sample to the requested proportions, i.e. how far the sample is from the requested proportions for that trait
      gaps <- c(gaps, sum_param) #stores the calculated gap in a list
    }
    names(gaps) <- names(proportions)
    gaps <- unlist(gaps) #all the gaps of the sample for each ecological parameter
    sum(gaps)
    weighted_mean <- sum(gaps * traits_weight) #weighted mean of the gaps for each parameter, relatively to their assigned weight -> one value that represents how far the sample in from the requested proportions.
  }


  #history
  if(history ==TRUE) { #create a list to store the history
    hist <- list(sample)
    k=length(sample)+1
  }

  while (length(sample) <n) { #while n is not reached
    #progress
    faith_sample <- epm::faithPD(tree, sample)
    perc_sample <- (faith_sample/tree_length)*100
    cat("Number of selected species :", length(sample), "/", n, " species", ", " , " faith = ", faith_sample, " % = ", perc_sample, "\n")


    #candidate species
    candidates <- setdiff(list, sample)

    if(length(candidates) == 0) break

    candidates
    table_candidates <- data.frame(Species = candidates)
    table_candidates$Faith <- purrr::map_dbl(table_candidates$Species, ~epm::faithPD(tree, c(.x, sample))) #for each candidate, calculates PD_Faith
    table_candidates$Traits.gap <- purrr::map_dbl(table_candidates$Species, ~gap_calculation(c(.x, sample), traits_table, proportions)) #for each candidate, calculates gap

    #Normalized values for Faith index and Traits Gap for the score calculation.
    faith_range <- range(table_candidates$Faith)
    if (diff(faith_range) == 0) {
      table_candidates$Faith_norm <- 0.5
    } else {
      table_candidates$Faith_norm <- (table_candidates$Faith - faith_range[1])/diff(faith_range) #normalization the PD_Faith between 0 and 1, with 1 = the highest value of PD_Faith.
    }

    traits_range <- range(table_candidates$Traits.gap)
    if (diff(traits_range) == 0) {
      table_candidates$Traits_norm <- 0.5
    } else {
      table_candidates$Traits_norm <- (traits_range[2] - table_candidates$Traits.gap)/diff(traits_range) #normalization the gaps between 0 and 1, with 1 = the smallest gap to requested proportions.
    }

    table_candidates$Score <- ((1 - delta) * table_candidates$Faith_norm + delta * table_candidates$Traits_norm) #final score for each species is weighted depending on lambda (more or less phylogeny)

    possible_candidates <- subset(table_candidates, table_candidates$Score == max(table_candidates$Score, na.rm = TRUE)) #keep candidates that maximise the final score (i.e. maximise PD_Faith and minimise ecological gap)
    possible_candidates <- possible_candidates$Species
    possible_candidates
    best_candidate <- sample(possible_candidates, size=1) #take one of the candidates
    best_candidate
    sample <- c(sample, best_candidate)

    if (history==TRUE) {
      hist[[k]] <- c(possible_candidates) #store the other candidates in history
      k=k+1
    }

    #progress
    faith_sample <- epm::faithPD(tree, sample)
    perc_sample <- (faith_sample/tree_length)*100
    cat("Number of selected species :", length(sample), "/", n, " species", ", " , " PD_Faith = ", faith_sample, " PPR = ", perc_sample, "% \n")

  }


  #print reached traits proportions of the created sample
  asked_param <- names(proportions)
  reached_traits <- list() #storage
  for (i in 1:length(asked_param)) {
    current_param <- asked_param[[i]] #take each parameter one by one
    param_ech <- traits_table[[current_param]][match(sample, traits_table$Species)]
    categories <- traits_table[[current_param]] %>% unique() #find the number of categories
    categories <- unlist(categories)
    counts_ech <- table(factor(param_ech, levels = categories)) #counts in the categories
    summary_current_traits <- list(counts_ech, prop.table(counts_ech)) #calculate also the proportions
    names(summary_current_traits) <- c("Counts", "Proportions")
    reached_traits[[paste0(current_param)]] <- summary_current_traits
  }

  faith_sample <- epm::faithPD(tree,sample) #faith index of the final sample
  perc_sample <- (faith_sample/tree_length)*100 #PPR of the final sample

  result <- list(hist, sample, faith_sample, perc_sample, reached_traits)
  names(result) <- c("History", "Best_sample", "PD_Faith", "PPR", "Traits")

  if (sub_phylo == TRUE) {
    sub.tree <- ape::drop.tip(tree, tree$tip.label[-match(sample, tree$tip.label)])
    result[["Phylogeny"]] <- sub.tree

    if (is.null(save_sub_phylo)){
      plot(sub.tree, type="fan", cex=0.5)
    }

    else {
      plot(sub.tree, type="fan", cex=0.5)
      ape::write.nexus(sub.tree, file=file.path(save_sub_phylo)) #save the sample
    }
  }
  return(result)
}

