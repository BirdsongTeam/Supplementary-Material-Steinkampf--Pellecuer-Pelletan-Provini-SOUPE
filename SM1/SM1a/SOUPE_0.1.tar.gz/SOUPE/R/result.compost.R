#' @title result.compost
#' @author Nyniane Steinkampf--Pellecuer <nyniane.steinkampf-pellecuer@mnhn.fr>
#'
#' @description Analyses the results of the compost function.
#'
#' @param tree the phylogenetic \code{tree} of the master group. By default, tree = NULL, must be defined by the user.
#' @param data the output of compost function. By default, data = NULL, must be defined by the user.
#' @param boxplot a \code{logical}. If boxplot = TRUE, creates a boxplot of the PD_Faith values. By default, boxplot = TRUE.
#' @param ttest a \code{logical}. If ttest = TRUE, a one sample one tail T-test is conducted. The hypothesis being tested are : H0 the mean of the PD_Faith values are higher or equal to the PD_Faith of the tested sample; H1 the mean of the PD_Faith values are lower than the PD_Faith of the tested sample. By default, ttest = TRUE.
#' @param best_random_sample a \code{logical}. If best_random_sample = TRUE, print the random sample that gave the best PD_Faith. By default, best_random_sample = TRUE.
#' @param save_best_random_sample only if best_random_sample = TRUE. Give the path of a location to save the best random sample and its PD_Faith in a csv file at this given location. If = NULL, the best sample is printed but not saved. By default, save_best_random_sample = NULL, the best random sample is not saved.
#' @return result a \code{list} with the following elements : Tested sample : the PD_Faith and PPR (Percentage of Phylogeny Represented) of the tested sample. Mean : the mean PD_Faith values, and corresponding PPR. Maximum : the PD_Faith and PPR of the best random sample. Best random sample : if best_random_sample = TRUE, the best random sample. T-test : if ttest = TRUE, the result of the one sample one tail t-test.
#' @importFrom epm faithPD
#' @importFrom graphics stripchart legend
#' @importFrom stats t.test
#' @importFrom utils write.csv
#' @examples
#' #Creates 20 randomly generated samples and calculates their PD_Faith.
#' output_compost <- compost(tree = ex_tree,
#'                           sample = ex_tested_sample,
#'                           list = ex_tree$tip.label,
#'                           n = 20)
#'
#' #In this example, list=ex_tree$tip.label because there is no limit on the
#' #availability of the taxa. We could have use for example
#' #list = ex_available_taxa for a limited list of available taxa.
#'
#' #Check the list of the faith index of the randomly generated samples.
#' output_compost$Faith_values
#'
#' #Check the randomly generated samples.
#' output_compost$Generated_samples
#'
#' #Use the output of the compost function in the result.compost function to
#' #assess the quality of the sample.
#' result <- result.compost(tree = ex_tree,
#'                          data = output_compost,
#'                          boxplot = TRUE,
#'                          ttest = FALSE,
#'                          best_random_sample = TRUE)
#'
#' #Visualize the results.
#' result
#' @export
#'
#'

result.compost <- function(tree = NULL, data = NULL, boxplot = TRUE, ttest = TRUE, best_random_sample = TRUE, save_best_random_sample = NULL) {

  if (is.null(tree)==TRUE) {
    stop("tree is missing")
  }
  if (is.null(data)==TRUE) {
    stop("data is missing")
  }
  if (is.logical(boxplot) == FALSE) {
    stop("boxplot argument is not logical")
  }
  if (is.logical(ttest)==FALSE) {
    stop("ttest argument is not logical")
  }
  if (is.logical(best_random_sample)==FALSE) {
    stop("best_random_sample argument is not logical")
  }

  taxo_tree <- tree$tip.label
  tree_length <- epm::faithPD(tree, taxo_tree) #length of the tree to calculate PPR
  n <- length(data$Faith_values)-1 #number of random samples created

  faith_sample <- data$Faith_values[1] #PD_Faith tested sample
  perc_sample <- (faith_sample/tree_length)*100 #PPR tested sample

  faith_mean <- mean(data$Faith_values) #PD_Faith mean
  perc_mean <- (faith_mean/tree_length)*100 #PPR mean

  faith_max <- max(data$Faith_values) #PD_Faith best random sample
  perc_max <- (faith_max/tree_length)*100 #PPR best random sample

  result <- list() #storage for the values of PD_Faith and PPR for each (tested, mean, best random)
  result[["Tested_sample"]] <- c(faith_sample, perc_sample)
  names(result[["Tested_sample"]]) <- c("PD_Faith", "PPR")
  result[["Mean"]] <- c(faith_mean, perc_mean)
  names(result[["Mean"]]) <- c("PD_Faith", "PPR")
  result[["Maximum"]] <- c(faith_max, perc_max)
  names(result[["Maximum"]]) <- c("PD_Faith", "PPR")


  if (boxplot==TRUE) {
    boxplot(data$Faith_values,  main=c("Boxplot of the distribution of PD_Faith for", n, " random samples"))
    graphics::stripchart(faith_sample, method = "jitter", pch = 19, col = 4, vertical = TRUE, add=TRUE, ) #point for tested sample
    graphics::stripchart(faith_max, method = "jitter", pch = 19, col = 2, vertical = TRUE, add=TRUE, ) #point for best random sample
    graphics::stripchart(faith_mean, method = "jitter", pch = 19, col = 1, vertical = TRUE, add=TRUE, ) #point for mean
    graphics::legend(x= "bottomright", legend = c(paste0("Tested sample : ", round(faith_sample, digits=2), ", ", round(perc_sample, digits=2), "%"),
                                                  paste0("Best random sample : ", round(faith_max, digits=2), ", ", round(perc_max, digits=2), "%"),
                                                  paste0("Mean : ", round(faith_mean, digits=2), ", ", round(perc_mean, digits=2), "%")),
                     col = c(4,2,1), cex=0.7, pch = 19, bty = 'o', title = "Legend") #legend
  }

  if (ttest==TRUE) {
    test <- stats::t.test(data$Faith_values, alternative = "less", mu = faith_sample) #one sample one tail t test : H0 : mean >= PD_Faith tested sample; H1 : mean < PD_Faith tested sample
    print(test)
    result[["T-test"]] <- test
  }

  if (best_random_sample==TRUE){
    index <- which(faith_max == data$Faith_values)[[1]]
    best_sample <- data$Generated_samples[[index]] #find the list of taxa that gave the highest PD_Faith in the random samples
    result[["Best_random_sample"]] <- best_sample

    if (is.null(save_best_random_sample)){
      print(best_sample)
    }

    else {
      print(best_sample)
      utils::write.csv(best_sample, file.path(save_best_random_sample)) #save the sample
    }
  }

  return(result)
}
