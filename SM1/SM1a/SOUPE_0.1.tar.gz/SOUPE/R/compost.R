#' @title compost
#' @author Nyniane Steinkampf--Pellecuer <nyniane.steinkampf-pellecuer@mnhn.fr>
#'
#' @description Creates random samples and calculates their PD_Faith.
#'
#' @param tree the phylogenetic \code{tree} of the master group. By default, tree = NULL, must be defined by the user.
#' @param sample a \code{string} with the taxa present in the tested sample. The names of the taxa have to match the labels of the phylogenetic tree. By default, sample = NULL, must be defined by the user.
#' @param list a \code{string} with the available taxa. The names of the taxa have to match the labels of the phylogenetic tree. If there is no restriction on the availability of the taxa, write list = tree$tip.labels ("tree" being the name of the phylogenetic tree). By default, list = NULL, must be defined by the user.
#' @param n the number of random samples to be generated. Check the maximal number of different samples that can be generated depending on the size of the master group or that of the available taxa, with the formula : n = (l!)/(t!(l-t)!) where n is the number of possible samples, l is the size of the sample (i.e. the number of taxa in the tested sample), t is the number of taxa available for the study (i.e. either the number of taxa in the master group, or the number of taxa in the availability list). If n<1000, chose n-1, if n>1000, chose 1000 or more. By default, n = 1000.
#' @return A \code{list} containing two elements : Faith_values : the PD_Faith values for the randomly generated samples and the tested sample. Generated_samples : the generated samples.
#' @importFrom epm faithPD
#' @importFrom utils txtProgressBar setTxtProgressBar
#' @examples
#' #Creates 20 randomly generated samples and calculates their PD_Faith.
#' output_compost <- compost(tree = ex_tree,
#'                           sample = ex_tested_sample,
#'                           list = ex_tree$tip.label,
#'                           n = 20)
#'
#' #In this example, list=ex_tree$tip.label because there is no limit on the
#' #availability of the taxa. We could have use for example
#' #list = ex_available_taxa for a limited list of available taxa.
#'
#' #Check the list of the PD_Faith of the randomly generated samples.
#' output_compost$Faith_values
#'
#' #Check the randomly generated samples.
#' output_compost$Generated_samples
#'
#' #Use the output of the compost function in the result.compost function to
#' #assess the quality of the sample.
#' result <- result.compost(tree = ex_tree,
#'                          data = output_compost,
#'                          boxplot = TRUE,
#'                          ttest = FALSE,
#'                          best_random_sample = TRUE)
#'
#' #Visualize the results.
#' result
#' @export
#'
#'

compost <- function(tree = NULL, sample = NULL, list = NULL, n = 1000){

  if (is.null(tree)==TRUE) {
    stop("tree is missing")
  }
  if (is.null(sample)==TRUE) {
    stop("sample is missing")
  }
  if (is.null(list)==TRUE) {
    stop("list of available taxa is missing")
  }
  if (is.numeric(n) == FALSE) {
    stop("n isn't a number")
  }
  if (all(sample %in% tree$tip.label) == FALSE) {
    stop("sample species don't match phylogenetic tree species")
  }
  if (all(sample %in% list) == FALSE) {
    stop("sample species don't match available species")
  }
  if (all(list %in% tree$tip.label) == FALSE) {
    stop("available species don't match phylogenetic tree species")
  }

  faith_index_ech <- epm::faithPD(tree, sample) #PD_Faith of the tested sample
  sample_size=length(sample) #size of the sample

  #storage
  faith_values <-list(faith_index_ech)
  samples <- list(sample)
  verif_diff <- list()

  #progress
  pb <- utils::txtProgressBar(min = 0, max = n, style = 3)

  while (length(samples) <n+1) {
    subsample <- sample(x=list, size=sample_size) #create a random sample

    for (i in 1:length(samples)) { #compare the random sample to the previous samples created to prevent duplicates
      if (setequal(subsample, samples[[i]]) ==TRUE){
        verif_diff[i] <- "TRUE"
      } else {
        verif_diff[i] <- "FALSE"
      }
    }
    if (all(verif_diff[!is.na(verif_diff)] == FALSE) == TRUE) { #if the sample is new, calculates its PD_Faith
      #PD_Faith
      x <- epm::faithPD(tree, subsample)

      #add PD_Faith value
      j=length(samples)+1
      faith_values[[j]] <- x

      #add taxa list
      samples[[j]] <- subsample

      #progress
      utils::setTxtProgressBar(pb, j)

    } else next
  }
  unlistfaith <- unlist(faith_values)
  result <- list(unlistfaith, samples)
  names(result) <- c("Faith_values", "Generated_samples")
  return(result)

}


