#' @title metrics
#' @author Nyniane Steinkampf--Pellecuer <nyniane.steinkampf-pellecuer@mnhn.fr>
#'
#' @description Gives the basic metrics of a sample : PD_Faith, Percentage of phylogeny represented (PPR), Traits proportions
#'
#' @param tree the phylogenetic \code{tree} of the master group. By default, tree = NULL, must be defined by the user.
#' @param sample a \code{string} with the taxa present in the tested sample. The names of the taxa have to match the labels of the phylogenetic tree.  By default, sample = NULL, must be defined by the user.
#' @param faith a \code{logical}. If faith=TRUE, calculates the Faith index (PD_Faith) of the sample. By default, faith=TRUE.
#' @param percentage a \code{logical}. If percentage=TRUE, calculates the percentage of phylogeny represented by the sample (PPR). It is calculated with the formula : (PD_Faith of the sample)/(Length of the tree) *100. By default percentage = TRUE.
#' @param traits a \code{logical}. If traits=TRUE, calculates the proportions and number of taxa for each traits characteristics. By default, traits = TRUE.
#' @param traits_table a \code{data.frame} with the traits characteristics of each species. These traits and characteristics have to be discrete and non-numeric. First column must be named "Species" and contains the species of the phylogenetic tree. By default, traits.table = NULL, must be defined by the user.
#' @param sub_phylo a \code{logical}. If sub_phylo=TRUE, plot the fan phylogenetic tree of the sample species, based on the master-group tree. By default, sub_phylo = TRUE.
#' @param save_sub_phylo only if sub_phylo = TRUE. Give the path of a location to save the phylogeny of the sample in a nexus file at this given location. If save_sub_phylo = NULL, the phylogeny is plotted but not saved. By default, save_sub_phylo = NULL, the phylogeny is not saved.
#' @return a \code{list} with the following elements : PD_Faith : the PD_Faith value of the sample. PPR : the Percentage of Phylogeny Represented of the sample. Traits : the proportions and number of taxa in each traits. Phylogeny : if sub_phylo = TRUE, the phylogenetic tree of the sample.
#' @importFrom epm faithPD
#' @importFrom ape write.nexus drop.tip
#' @importFrom purrr %>%
#' @examples
#' metrics(tree = ex_tree,
#'         sample = ex_tested_sample,
#'         faith = TRUE,
#'         percentage = TRUE,
#'         traits = TRUE,
#'         traits_table = ex_traits_table,
#'         sub_phylo = TRUE)
#' @export
#'
#'


metrics <- function(tree = NULL, sample = NULL, faith = TRUE, percentage = TRUE, traits = TRUE, traits_table = NULL, sub_phylo = TRUE, save_sub_phylo = NULL) {

  if (is.null(tree)==TRUE) {
    stop("tree is missing")
  }
  if (is.null(sample)==TRUE) {
    stop("sample is missing")
  }
  if (is.logical(faith)==FALSE) {
    stop("faith argument is not logical")
  }
  if (is.logical(percentage)==FALSE) {
    stop("percentage argument is not logical")
  }
  if (is.logical(traits)==FALSE) {
    stop("traits argument is not logical")
  }
  if (all(sample %in% tree$tip.label) == FALSE) {
    stop("sample species don't match phylogenetic tree species")
  }
  if (all(traits_table$Species %in% tree$tip.label) == FALSE) {
    stop("traits table species don't match phylogenetic tree species")
  }
  if (all(sample %in% traits_table$Species) == FALSE) {
    stop("sample species don't match traits table species")
  }

  faith_index_ech <- epm::faithPD(tree, sample) #PD_Faith of the sample
  taxo_tree <- tree$tip.label
  tree_length <- epm::faithPD(tree, taxo_tree) #length of the tree, to calculate the PPR
  perc_ech <- (faith_index_ech/tree_length)*100 #PPR
  result <- list()

  if (faith==TRUE) {
    print("Sample PD_Faith")
    print(faith_index_ech)
    result[["PD_Faith"]] <- faith_index_ech
  }

  if (percentage==TRUE) {
    print("Sample PPR")
    print(perc_ech)
    result[["PPR"]] <- perc_ech
  }

  if (traits==TRUE) {
    trait <- list()
    if(is.null(traits_table)) { #if no traits table is given, it doesn't work
      stop("The traits table is missing")
    }

    all_param <- colnames(traits_table)
    for (i in 2:ncol(traits_table)) {
      current_param <- all_param[[i]] #take each parameter one by one
      param_ech <- traits_table[[i]][match(sample, traits_table$Species)]
      param_ech <- unlist(param_ech)
      categories <- traits_table[[i]] %>% unique() #the categories in the parameter
      categories <- unlist(categories)
      counts_ech <- table(factor(param_ech, levels = categories)) #calculate the counts in each categories of the parameter
      prop_ech <- prop.table(counts_ech)
      prop_ech_round <- round(prop_ech, 2)
      summary_current_trait <- list(counts_ech, prop_ech_round) #calculate also the proportions
      names(summary_current_trait) <- c("Counts", "Proportions")
      trait[[paste0(current_param)]] <- summary_current_trait
      print(trait)
      result[["Traits"]] <- trait
    }
  }

  if (sub_phylo == TRUE) {
    sub.tree <- ape::drop.tip(tree,tree$tip.label[-match(sample, tree$tip.label)])
    result[["Phylogeny"]] <- sub.tree

    if (is.null(save_sub_phylo)){
      plot(sub.tree, type="fan", cex=0.5)
    }

    else {
      plot(sub.tree, type="fan", cex=0.5)
      ape::write.nexus(sub.tree, file=file.path(save_sub_phylo)) #save the sample
    }
  }

  return(result)
}



